package com.snhu.cs360_projecttwo.ui;

import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.snhu.cs360_projecttwo.R;
import com.snhu.cs360_projecttwo.connectors.InventoryAppDatabase;

public class LandingFragment extends Fragment {
    private EditText editUsername, editPassword;
    private InventoryAppDatabase db;

    public LandingFragment() {}

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_landing, container, false);

        editUsername = view.findViewById(R.id.editName);
        editPassword = view.findViewById(R.id.editPassword);
        Button loginButton = view.findViewById(R.id.loginButton);
        Button signupButton = view.findViewById(R.id.signupButton);

        db = new InventoryAppDatabase(requireContext());

        loginButton.setOnClickListener(v -> {
            String user = editUsername.getText().toString();
            String pass = editPassword.getText().toString();

            if (!user.isEmpty() && !pass.isEmpty()) {
                Cursor userCursor = db.login(user, pass);
                if (userCursor.moveToFirst()) {
                    requireActivity().getSupportFragmentManager().beginTransaction()
                            .replace(R.id.nav_host_fragment, new ItemListFragment())
                            .addToBackStack(null)
                            .commit();
                } else {
                    Toast.makeText(getContext(), getString(R.string.invalid_user), Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(getContext(), getString(R.string.details_required), Toast.LENGTH_SHORT).show();
            }
        });

        signupButton.setOnClickListener(v -> {
            String user = editUsername.getText().toString();
            String pass = editPassword.getText().toString();

            if (!user.isEmpty() && !pass.isEmpty()) {
                long userCursor = db.insertUser(user, pass);

                if (userCursor != -1) {
                    requireActivity().getSupportFragmentManager().beginTransaction()
                            .replace(R.id.nav_host_fragment, new ItemListFragment())
                            .addToBackStack(null)
                            .commit();
                    Toast.makeText(getContext(), getString(R.string.user_created), Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getContext(), getString(R.string.invalid_user), Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(getContext(), getString(R.string.user_created), Toast.LENGTH_SHORT).show();
            }
        });

        return view;
    }
}