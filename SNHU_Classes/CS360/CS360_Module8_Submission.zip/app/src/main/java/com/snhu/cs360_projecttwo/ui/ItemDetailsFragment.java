package com.snhu.cs360_projecttwo.ui;

import android.os.Bundle;

import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.snhu.cs360_projecttwo.R;
import com.snhu.cs360_projecttwo.connectors.InventoryAppDatabase;

public class ItemDetailsFragment extends Fragment {
    private InventoryAppDatabase db;

    private int itemId;
    private String itemName;
    private int itemCount;

    private EditText editName;
    private EditText editQuantity;

    public ItemDetailsFragment() {}

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getArguments() != null) {
            itemId = getArguments().getInt("id");
            itemName = getArguments().getString("name");
            itemCount = getArguments().getInt("quantity");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_item_details, container, false);
        editName = view.findViewById(R.id.editName);
        editQuantity = view.findViewById(R.id.editQuantity);

        db = new InventoryAppDatabase(requireContext());
        Button btnSave = view.findViewById(R.id.saveDetails);
        Button btnCancel = view.findViewById(R.id.cancelEdits);
        Button btnRemove = view.findViewById(R.id.removeItem);

        editName.setText(itemName);
        editQuantity.setText(String.valueOf(itemCount));

        btnSave.setOnClickListener(v -> {
            String newName = editName.getText().toString().trim();
            String newQtyStr = editQuantity.getText().toString().trim();

            if (newName.isEmpty() || newQtyStr.isEmpty()) {
                Toast.makeText(getContext(), getString(R.string.details_empty_warning), Toast.LENGTH_SHORT).show();
                return;
            }

            int newQty = Integer.parseInt(newQtyStr);
            int updated = db.updateItem(itemId, newName, newQty);

            if (updated > 0) {
                Toast.makeText(getContext(), getString(R.string.update_success), Toast.LENGTH_SHORT).show();
                goBack();
            } else {
                Toast.makeText(getContext(), getString(R.string.update_failed), Toast.LENGTH_SHORT).show();
            }
        });



        btnRemove.setOnClickListener(v -> {
            int deleted = db.deleteItemById(itemId);

            if (deleted > 0) {
                Toast.makeText(getContext(), getString(R.string.remove_success), Toast.LENGTH_SHORT).show();
                goBack();
            } else {
                Toast.makeText(getContext(), getString(R.string.remove_failed), Toast.LENGTH_SHORT).show();
            }
        });

        btnCancel.setOnClickListener(v -> goBack());

        Toolbar toolbar = view.findViewById(R.id.topAppBar);
        toolbar.setNavigationOnClickListener(v -> goBack());

        return view;
    }

    private void goBack() {
        requireActivity().getSupportFragmentManager().popBackStack();
    }
}