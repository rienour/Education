package com.snhu.cs360_projecttwo.models;

public class InventoryItem {
    private final int id;
    private final String name;
    private final int quantity;


    public InventoryItem(int id, String name, int quantity) {
        this.name = name;
        this.id = id;
        this.quantity = quantity;
    }

    /**
     * Getter for the name
     *
     * @return String of the name
     */
    public String getName() {
        return this.name;
    }

    /**
     * Getter for the quantity
     *
     * @return Int quantity of the item
     */
    public int getQuantity() {
        return this.quantity;
    }

    /**
     * Getter for the id
     *
     * @return int id of the item
     */
    public int getId() {
        return this.id;
    }
}
