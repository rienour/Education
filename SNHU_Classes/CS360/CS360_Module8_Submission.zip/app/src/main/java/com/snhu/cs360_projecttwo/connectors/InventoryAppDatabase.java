package com.snhu.cs360_projecttwo.connectors;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class InventoryAppDatabase extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "inventory_app.db";
    private static final int VERSION = 1;

    public InventoryAppDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    /**
     * This table will house the information for the users of the application
     */
    protected static final class UserTable {
        private static final String TABLE_NAME = "users";
        private static final String COL_ID = "id";
        private static final String COL_USERNAME = "username";
        private static final String COL_PASSWORD = "password";
    }

    /**
     * This table will house the items for a user of the application
     * Records are deleted with the user
     */
    protected static final class ItemTable {
        private static final String TABLE_NAME = "items";
        private static final String COL_ID = "id";
        private static final String COL_NAME = "name";
        private static final String COL_QUANTITY = "quantity";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create Users table
        db.execSQL("create table " + UserTable.TABLE_NAME + " (" +
                UserTable.COL_ID + " integer primary key autoincrement, " +
                UserTable.COL_USERNAME + " text unique, " +
                UserTable.COL_PASSWORD + " text)");

        // Create Items table
        db.execSQL("create table " + ItemTable.TABLE_NAME + " (" +
                ItemTable.COL_ID + " integer primary key autoincrement, " +
                ItemTable.COL_NAME + " integer, " +
                ItemTable.COL_QUANTITY + " integer)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion,
                          int newVersion) {
        db.execSQL("drop table if exists " + UserTable.TABLE_NAME);
        db.execSQL("drop table if exists " + ItemTable.TABLE_NAME);
        onCreate(db);
    }

    /**
     * Search for a user in the database by username and password
     *
     * @param username String for the username to check
     * @return Cursor for the users table
     */
    public Cursor login(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();

        return db.query(
                UserTable.TABLE_NAME,
                null,
                UserTable.COL_USERNAME + " = ? and " + UserTable.COL_PASSWORD + " = ?",
                new String[]{
                        username,
                        password,
                },
                null,
                null,
                null
        );
    }

    /**
     * Search for the items by user id
     *
     * @return Cursor for the items table
     */
    public Cursor findItemsByUserId() {
        SQLiteDatabase db = this.getReadableDatabase();

        return db.query(
                ItemTable.TABLE_NAME,
                null,
                null,
                null,
                null,
                null,
                null);
    }

    /**
     * Deletes an item given the item and user id
     *
     * @param itemId Item id to remove
     * @return int
     */
    public int deleteItemById(int itemId) {
        SQLiteDatabase db = this.getWritableDatabase();

        return db.delete(
                ItemTable.TABLE_NAME,
                ItemTable.COL_ID + " = ?",
                new String[]{
                        String.valueOf(itemId)
                });
    }

    /**
     * Updates an item record given item id and new attributes
     *
     * @param itemId Item to update
     * @param name new name value for the item
     * @param quantity new quantity for the item
     *
     * @return int representing updated row count
     */
    public int updateItem(int itemId, String name, int quantity) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(ItemTable.COL_NAME, name);
        values.put(ItemTable.COL_QUANTITY, quantity);

        return db.update(
                ItemTable.TABLE_NAME,
                values,
                ItemTable.COL_ID + " = ?",
                new String[]{
                        String.valueOf(itemId)
                });
    }

    /**
     * Insert a new user given username and password
     *
     * @param username new username for the user record
     * @param password new password for the user record
     *
     * @return int id of the user
     */
    public long insertUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(UserTable.COL_USERNAME, username);
        values.put(UserTable.COL_PASSWORD, password);

        return db.insert(UserTable.TABLE_NAME, null, values);
    }

    /**
     * Insert a new user given username and password
     *
     * @param name new name for the item record
     * @param quantity new password for the item record
     *
     * @return long id of the item
     */
    public long insertItem(String name, int quantity) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(ItemTable.COL_NAME, name);
        values.put(ItemTable.COL_QUANTITY, quantity);

        return db.insert(ItemTable.TABLE_NAME, null, values);
    }
}
