package com.snhu.cs360_projecttwo.ui;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.snhu.cs360_projecttwo.R;
import com.snhu.cs360_projecttwo.connectors.InventoryAppDatabase;
import com.snhu.cs360_projecttwo.models.InventoryItem;

import java.util.ArrayList;
import java.util.List;

public class ItemListFragment extends Fragment {
    private ItemListAdapter itemAdapter;
    private List<InventoryItem> itemList;
    private InventoryAppDatabase db;
    private boolean userAgreedToSMS = false;
    private boolean smsDialogShown = false;

    public ItemListFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_item_list, container, false);

        RecyclerView recyclerView = view.findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));
        ImageView menuIcon = view.findViewById(R.id.menuIcon);
        menuIcon.setOnClickListener(v -> showSMSPermissionDialog());

        FloatingActionButton fabAddItem = view.findViewById(R.id.addItem);
        fabAddItem.setOnClickListener(v -> showAddItemDialog());

        db = new InventoryAppDatabase(requireContext());
        itemList = getUserItems();
        itemAdapter = new ItemListAdapter(itemList, item -> {
            ItemDetailsFragment detailsFragment = new ItemDetailsFragment();

            Bundle bundle = new Bundle();
            bundle.putInt("id", item.getId());
            bundle.putString("name", item.getName());
            bundle.putInt("quantity", item.getQuantity());
            detailsFragment.setArguments(bundle);

            requireActivity().getSupportFragmentManager().beginTransaction()
                    .replace(R.id.nav_host_fragment, detailsFragment)
                    .addToBackStack(null)
                    .commit();
        });
        recyclerView.setAdapter(itemAdapter);

        return view;
    }

    private List<InventoryItem> getUserItems() {
        List<InventoryItem> list = new ArrayList<>();
        Cursor cursor = db.findItemsByUserId();

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
                String name = cursor.getString(cursor.getColumnIndexOrThrow("name"));
                int count = cursor.getInt(cursor.getColumnIndexOrThrow("quantity"));
                list.add(new InventoryItem(id, name, count));
            } while (cursor.moveToNext());
        }

        cursor.close();

        checkAndSendLowInventoryAlert(list);
        return list;
    }

    private void showAddItemDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
        builder.setTitle(getString(R.string.add_item));

        View dialogView = getLayoutInflater().inflate(R.layout.fragment_add_item, null);
        EditText editName = dialogView.findViewById(R.id.itemName);
        EditText editQuantity = dialogView.findViewById(R.id.itemQuantity);
        builder.setView(dialogView);

        builder.setPositiveButton(getString(R.string.add), (dialog, which) -> {
            String name = editName.getText().toString().trim();
            String quantity = editQuantity.getText().toString().trim();

            if (!name.isEmpty() && !quantity.isEmpty()) {
                int count = Integer.parseInt(quantity);
                long success = db.insertItem(name, count);
                if (success != -1) {
                    // Reload list
                    itemList.clear();
                    itemList.addAll(getUserItems());
                    itemAdapter.notifyDataSetChanged();
                    Toast.makeText(getContext(), getString(R.string.add_success), Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getContext(), getString(R.string.add_failed), Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(getContext(), getString(R.string.details_empty_warning), Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton(getString(R.string.cancel), null);
        builder.show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == 101) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(getContext(), getString(R.string.granted_sms), Toast.LENGTH_SHORT).show();
                // You can now send SMS later
            } else {
                Toast.makeText(getContext(), getString(R.string.denied_sms), Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void showSMSPermissionDialog() {
        new AlertDialog.Builder(requireContext())
                .setTitle(getString(R.string.permission_title))
                .setMessage(getString(R.string.permission_message))
                .setPositiveButton(getString(R.string.permission_allow), (dialog, which) -> {
                    userAgreedToSMS = true;
                    checkAndSendLowInventoryAlert(itemList);
                })
                .setNegativeButton(getString(R.string.permission_deny), (dialog, which) -> {
                    userAgreedToSMS = false;
                    Toast.makeText(getContext(), getString(R.string.denied_sms), Toast.LENGTH_SHORT).show();
                })
                .show();
    }


    private void sendSMS(String phoneNumber, String message) {
        if(!smsDialogShown) {
            smsDialogShown = true;
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse("sms:" + phoneNumber));
            intent.putExtra("sms_body", message);

            try {
                startActivity(intent);
            } catch (ActivityNotFoundException e) {
                Toast.makeText(getContext(), getString(R.string.no_sms_warning), Toast.LENGTH_SHORT).show();
            }
        }

    }

    private void checkAndSendLowInventoryAlert(List<InventoryItem> itemList) {
        boolean sendMessage = false;
        StringBuilder outputMessage = new StringBuilder(getString(R.string.no_sms_warning));
        outputMessage.append("\n");

        for (InventoryItem item : itemList) {
            if (item.getQuantity() == 0) {
                outputMessage.append(item.getName()).append("\n");
                sendMessage = true;
            }
        }

        if (sendMessage && userAgreedToSMS) {
            sendSMS("", outputMessage.toString());
        }
    }

}

